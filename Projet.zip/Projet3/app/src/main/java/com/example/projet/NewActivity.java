package com.example.projet;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class NewActivity extends AppCompatActivity {
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);
        btn = findViewById(R.id.btnSc);
        btn.setOnClickListener(v->{
            Scanner();

        });
    }
    private void Scanner() {
        ScanOptions op = new ScanOptions();
        op.setPrompt("Volume up flash up");
        op.setBeepEnabled(true);
        op.setOrientationLocked(true);
        op.setCaptureActivity(CaptAct.class);
        barLauncher.launch(op);
    }
    ActivityResultLauncher<ScanOptions> barLauncher = registerForActivityResult(new ScanContract(), result -> {
        if(result.getContents()!=null){
            AlertDialog.Builder builder = new AlertDialog.Builder(NewActivity.this);
            builder.setTitle("Résultat");
            builder.setMessage(result.getContents());
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    if(result.getContents().toString().equals("123456789"))
                        lancerApp();
                    dialogInterface.dismiss();
                }
            }).show();
        }
    });
    private void lancerApp(){
        Intent intent = new Intent(this, NewNewActivity.class);
        startActivity(intent);
    }
}