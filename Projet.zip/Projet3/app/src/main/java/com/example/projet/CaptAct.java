package com.example.projet;

import com.journeyapps.barcodescanner.CaptureActivity;

public class CaptAct extends CaptureActivity {
}